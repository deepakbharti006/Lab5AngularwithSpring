import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { stringify } from 'querystring';
import { Movie } from './model/movie';

@Injectable({
  providedIn: 'root'
})
export class MovieServiceService {

  private movies: Movie[]=[];
 
  constructor(private http: HttpClient) { }

  /*********************************************************************
   * Method: loadBooks
   * params: 
   * return: Observable
   * Description: this method is hitting json file 
   *              
   * Created Date: 
   * Author: 
   ************************************************************************/
  
  loadMovies():Observable<any>{
    //let url = "../assets/booklist.json";

    return this.http.get("http://localhost:8084/movies");
  }

  /*********************************************************************
   * Method: setBooks
   * params: book
   * return: void
   * Description:  this method is seting the values of book into the book array
   *              
   * Created Date: 
   * Author: 
   ************************************************************************/
  setMovies(movies:Movie[]):void {
    this.movies=movies;
  }
  /*********************************************************************
   * Method: getBooks
   * params: 
   * return: Book[]
   * Description: this methood is returning the book instance after seting
   *              
   * Created Date: 
   * Author: 
   ************************************************************************/
  getMovies():Movie[]{
    return this.movies;
  }

  /*********************************************************************
   * Method: insertBook
   * params: book
   * return: 
   * Description: this method pushing the data using book instance
   *              
   * Created Date: 
   * Author: 
   ************************************************************************/
  insertMovies(movie:Movie):Observable<any>{
    //this.books.push(book);
    //const str=JSON.stringify(book);
    //console.log(str);
    return this.http.post("http://localhost:8084/movies",this.movies,{responseType:"text"});
  }
 
}