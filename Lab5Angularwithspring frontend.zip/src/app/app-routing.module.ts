import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewmovieComponent } from './viewmovie/viewmovie.component';
import { AddmovieComponent } from './addmovie/addmovie.component';




const routes: Routes = [
  { path: 'add', component: AddmovieComponent },
  { path: 'view', component: ViewmovieComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

