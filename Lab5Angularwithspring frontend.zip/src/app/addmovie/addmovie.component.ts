import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Movie } from '../model/movie';
import { MovieServiceService } from '../movie-service.service';

@Component({
  selector: 'app-addmovie',
  templateUrl: './addmovie.component.html',
  styleUrls: ['./addmovie.component.scss']
})
export class AddmovieComponent {

  /*********************************************************************
   *  Instance of Book for manupulation
   **********************************************************************/
  movie: Movie = new Movie();

   /*********************************************************************
   * Method: constructor
   * params:
   * return:
   * Description: constructor injects the bookService and router module 
   *              
   * Created Date: 05 MAY 2020
   * Author: Deepak Bharti
   ************************************************************************/

  
  constructor(private movieService: MovieServiceService, private route: Router) { }

  /********************************************************************************
   * Method: addBook
   * params:
   * return:
   * Description: this method call service addBooks method and add books every time
   *              and routes the page to display all book detail after adding
   * Created Date: 05 MAY 2020
   * Author: Deepak Bharti
   **********************************************************************************/

  addMovie() {
    console.log("add movie");
    this.movieService.insertMovies(this.movie).subscribe(data=>{this.movie=data});
    this.route.navigateByUrl("/view");
  }
}