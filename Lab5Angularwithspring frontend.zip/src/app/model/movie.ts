export class Movie {
    movieId: number;
    movieName: string;
    movieRating: number;
    movieGenre: string;
  }
  