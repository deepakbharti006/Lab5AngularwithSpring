import { Component, OnInit } from '@angular/core';
import { ThrowStmt } from '@angular/compiler';
import { Movie } from '../model/movie';
import { MovieServiceService } from '../movie-service.service';

@Component({
  selector: 'app-viewmovie',
  templateUrl: './viewmovie.component.html',
  styleUrls: ['./viewmovie.component.scss']
})
export class ViewmovieComponent implements OnInit {

  /**************************************************************************
   * creating books array of Book type to store the book detail 
  /**************************************************************************/
  movies: Movie[] = [];

  /*************************************************************************
   * creating book instance for every time manupulate the data
   *************************************************************************/

  movie: Movie = new Movie();
  /*************************************************************************
   * seting the flag false after enter the data it will ture and usable
   ************************************************************************/

  editFlag: boolean = false;
  constructor(private movieService: MovieServiceService) { }

   /*********************************************************************
   * Method: ngOnInit is life cycle hook called by angular at first
   * params:
   * return:
   * Description: ngOnInit first check the falg value if it is true then check
   *              and loads all the book in the starting and it is
   *              checking if book array length is zero then load book 
   *              and set the book into the current array
   *              
   * Created Date: 04 MAR 2020
   * Author: 
   ************************************************************************/

  ngOnInit() {
        this.movieService.loadMovies().subscribe(data => {
          this.movies = data;
          this.movieService.setMovies(this.movies);
        });
  }
}